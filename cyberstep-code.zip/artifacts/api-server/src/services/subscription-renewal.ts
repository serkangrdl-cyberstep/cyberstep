import cron from "node-cron";
import crypto from "crypto";
import { db } from "@workspace/db";
import { customerServicesTable, serviceCatalogTable, customersTable, customerServiceSubscriptionsTable } from "@workspace/db";
import { eq, and, lte, gte, isNull, between } from "drizzle-orm";
import { sendMail, sendSubscriptionExpiryReminder } from "./email";
import { logger } from "../lib/logger";

function generateRenewalToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

const MAX_RENEWAL_ATTEMPTS = 3;

async function sendRenewalFailureEmail(params: {
  email: string;
  companyName: string;
  serviceName: string;
  attempt: number;
}) {
  const messages: Record<number, string> = {
    1: "Abonelik yenileme ödemesi başarısız oldu. Lütfen ödeme bilgilerinizi güncelleyin.",
    2: "Son ödeme hatırlatması. Hesabınız 3 gün içinde askıya alınacak.",
    3: "Aboneliğiniz askıya alındı. Yeniden etkinleştirmek için ödeme yapın.",
  };

  const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body style="font-family:sans-serif;background:#f4f7fb;padding:32px">
<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;padding:32px">
  <h2 style="color:#ef4444;margin-top:0">Ödeme Uyarısı</h2>
  <p>Sayın <strong>${params.companyName}</strong>,</p>
  <p><strong>${params.serviceName}</strong> servisiniz için yenileme ödemesi alınamadı.</p>
  <p style="background:#fef2f2;padding:12px;border-radius:6px;color:#b91c1c">${messages[params.attempt] ?? messages[1]}</p>
  <a href="https://cyberstep.io/hesabim/servislerim" style="display:inline-block;background:#0ea5e9;color:#fff;padding:10px 20px;border-radius:6px;text-decoration:none;margin-top:16px">Ödemeyi Güncelle</a>
  <p style="color:#94a3b8;font-size:12px;margin-top:24px">CyberStep.io</p>
</div></body></html>`;

  await sendMail({ to: params.email, subject: `Ödeme Uyarısı: ${params.serviceName}`, html });
}

async function processRenewalFailure(cs: typeof customerServicesTable.$inferSelect, serviceName: string, email: string, companyName: string) {
  const attempt = (cs.renewalAttemptCount ?? 0) + 1;

  const updateData: Partial<typeof customerServicesTable.$inferInsert> = {
    renewalAttemptCount: attempt,
    lastRenewalFailedAt: new Date(),
  };

  if (attempt >= MAX_RENEWAL_ATTEMPTS) {
    updateData.status = "suspended";
    logger.warn({ customerId: cs.customerId, serviceName }, "Service suspended after max renewal attempts");
  }

  await db.update(customerServicesTable)
    .set(updateData)
    .where(eq(customerServicesTable.id, cs.id));

  setImmediate(() => {
    sendRenewalFailureEmail({ email, companyName, serviceName, attempt }).catch(() => {});
  });
}

export async function processSubscriptionRenewals() {
  const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);

  const renewals = await db
    .select({
      cs: customerServicesTable,
      service: serviceCatalogTable,
      customer: customersTable,
    })
    .from(customerServicesTable)
    .innerJoin(serviceCatalogTable, eq(customerServicesTable.serviceCatalogId, serviceCatalogTable.id))
    .innerJoin(customersTable, eq(customerServicesTable.customerId, customersTable.id))
    .where(
      and(
        eq(customerServicesTable.status, "active"),
        eq(customerServicesTable.autoRenew, true),
        lte(customerServicesTable.nextRenewalAt, tomorrow),
        gte(customerServicesTable.renewalAttemptCount, 0),
      )
    );

  logger.info({ count: renewals.length }, "Processing subscription renewals");

  for (const { cs, service, customer } of renewals) {
    try {
      const now = new Date();
      const serviceType = service.serviceType ?? "monthly";
      const newExpiry = serviceType === "annual"
        ? new Date(now.getFullYear() + 1, now.getMonth(), now.getDate())
        : new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());

      const { isIyzicoConfigured, createPaymentWithStoredCard } = await import("./iyzico");

      if (!isIyzicoConfigured()) {
        logger.warn({ csId: cs.id }, "İyzico yapılandırılmamış — manuel yenileme linki gönderiliyor");
        await processRenewalFailure(cs, service.label, customer.email, customer.companyName ?? "Müşteri");
        continue;
      }

      if (cs.customerId == null) {
        logger.warn({ csId: cs.id }, "customerId null — abonelik yenileme atlanıyor");
        continue;
      }
      const customerId: number = cs.customerId;
      const [sub] = await db
        .select({ cardUserKey: customerServiceSubscriptionsTable.iyzicoCardUserKey, cardToken: customerServiceSubscriptionsTable.iyzicoCardToken })
        .from(customerServiceSubscriptionsTable)
        .where(and(eq(customerServiceSubscriptionsTable.customerId, customerId), eq(customerServiceSubscriptionsTable.serviceSlug, service.slug)))
        .limit(1);

      if (!sub?.cardUserKey || !sub?.cardToken) {
        logger.info({ csId: cs.id }, "Kayıtlı kart bulunamadı — yenileme linki gönderiliyor");
        await processRenewalFailure(cs, service.label, customer.email, customer.companyName ?? "Müşteri");
        continue;
      }

      const priceTl = Number(service.priceTl ?? service.monthlyPriceTl ?? 0);
      const priceTlWithKdv = Math.round(priceTl * 1.20 * 100) / 100;
      const displayName = customer.fullName ?? customer.companyName ?? "Müşteri";
      const nameParts = displayName.split(" ");
      const firstName = nameParts[0] ?? "Müşteri";
      const lastName = nameParts.slice(1).join(" ") || ".";

      const result = await createPaymentWithStoredCard({
        price: String(priceTl),
        paidPrice: String(priceTlWithKdv),
        currency: "TRY",
        installment: 1,
        paymentCard: { cardUserKey: sub.cardUserKey, cardToken: sub.cardToken },
        buyer: {
          id: String(customer.id),
          name: firstName,
          surname: lastName,
          email: customer.email,
          identityNumber: "11111111111",
          registrationAddress: "Türkiye",
          city: "Istanbul",
          country: "Turkey",
          ip: "127.0.0.1",
        },
        shippingAddress: { address: "Türkiye", city: "Istanbul", country: "Turkey", contactName: displayName },
        billingAddress: { address: "Türkiye", city: "Istanbul", country: "Turkey", contactName: displayName },
        basketItems: [{
          id: String(cs.id),
          name: service.label,
          category1: "Yazılım",
          itemType: "VIRTUAL",
          price: String(priceTl),
        }],
        conversationId: crypto.randomBytes(8).toString("hex"),
      });

      if (result.success) {
        await db.update(customerServicesTable).set({
          renewalAttemptCount: 0,
          nextRenewalAt: newExpiry,
          lastRenewalFailedAt: null,
        }).where(eq(customerServicesTable.id, cs.id));

        logger.info({ csId: cs.id, customerId: cs.customerId, paymentId: result.paymentId }, "Otomatik abonelik yenileme başarılı");

        setImmediate(() => {
          void import("./email").then(({ sendMail }) => {
            sendMail({
              to: customer.email,
              subject: `${service.label} aboneliğiniz yenilendi`,
              html: `<p>Sayın ${customer.companyName ?? customer.fullName ?? "Değerli Müşteri"},</p><p><strong>${service.label}</strong> aboneliğiniz ${newExpiry.toLocaleDateString("tr-TR")} tarihine kadar yenilendi.</p><p>CyberStep.io</p>`,
            }).catch(() => {});
          });
        });
      } else {
        logger.warn({ csId: cs.id, errorMessage: result.errorMessage }, "Otomatik yenileme başarısız — dunning başlatılıyor");
        await processRenewalFailure(cs, service.label, customer.email, customer.companyName ?? "Müşteri");
      }
    } catch (err) {
      logger.error({ err, csId: cs.id }, "Renewal processing error");
    }
  }
}

export async function checkSubscriptionExpiryReminders(): Promise<void> {
  const now = new Date();

  // Window for 30-day reminder: expires_at between now+27d and now+33d
  const window30dFrom = new Date(now.getTime() + 27 * 24 * 3600 * 1000);
  const window30dTo   = new Date(now.getTime() + 33 * 24 * 3600 * 1000);

  // Window for 7-day reminder: expires_at between now+6d and now+8d
  const window7dFrom = new Date(now.getTime() + 6 * 24 * 3600 * 1000);
  const window7dTo   = new Date(now.getTime() + 8 * 24 * 3600 * 1000);

  // Window for 1-day reminder: expires_at between now+12h and now+36h
  const window1dFrom = new Date(now.getTime() + 12 * 3600 * 1000);
  const window1dTo   = new Date(now.getTime() + 36 * 3600 * 1000);

  const [due30d, due7d, due1d] = await Promise.all([
    db.select().from(customerServiceSubscriptionsTable).where(
      and(
        eq(customerServiceSubscriptionsTable.status, "active"),
        isNull(customerServiceSubscriptionsTable.reminder30dSentAt),
        between(customerServiceSubscriptionsTable.expiresAt, window30dFrom, window30dTo),
      ),
    ),
    db.select().from(customerServiceSubscriptionsTable).where(
      and(
        eq(customerServiceSubscriptionsTable.status, "active"),
        isNull(customerServiceSubscriptionsTable.reminder7dSentAt),
        between(customerServiceSubscriptionsTable.expiresAt, window7dFrom, window7dTo),
      ),
    ),
    db.select().from(customerServiceSubscriptionsTable).where(
      and(
        eq(customerServiceSubscriptionsTable.status, "active"),
        isNull(customerServiceSubscriptionsTable.reminder1dSentAt),
        between(customerServiceSubscriptionsTable.expiresAt, window1dFrom, window1dTo),
      ),
    ),
  ]);

  logger.info({ count30d: due30d.length, count7d: due7d.length, count1d: due1d.length }, "Subscription expiry reminders: candidates found");

  for (const sub of due30d) {
    if (!sub.expiresAt) continue;
    try {
      const token = generateRenewalToken();
      const tokenExpiresAt = new Date(Date.now() + 7 * 24 * 3600 * 1000);
      // Send email FIRST — flag is only written on success (write-after-send)
      await sendSubscriptionExpiryReminder({
        email: sub.email,
        contactName: sub.contactName,
        companyName: sub.companyName,
        serviceLabel: sub.serviceLabel,
        expiresAt: sub.expiresAt,
        daysLeft: 30,
        renewalToken: token,
      });
      // Atomic conditional update: only mark sent if not already flagged (idempotency)
      const result30d = await db.update(customerServiceSubscriptionsTable)
        .set({ renewalToken: token, renewalTokenExpiresAt: tokenExpiresAt, reminder30dSentAt: new Date() })
        .where(and(
          eq(customerServiceSubscriptionsTable.id, sub.id),
          isNull(customerServiceSubscriptionsTable.reminder30dSentAt),
        ));
      if ((result30d.rowCount ?? 0) === 0) {
        logger.warn({ subId: sub.id }, "30d reminder: row already marked, duplicate prevented");
      } else {
        logger.info({ subId: sub.id, email: sub.email }, "Subscription 30d reminder sent");
      }
    } catch (err) {
      logger.error({ err, subId: sub.id }, "Failed to send 30d reminder — will retry on next cron run");
    }
  }

  for (const sub of due7d) {
    if (!sub.expiresAt) continue;
    try {
      const token = generateRenewalToken();
      const tokenExpiresAt = new Date(Date.now() + 7 * 24 * 3600 * 1000);
      // Send email FIRST — flag is only written on success (write-after-send)
      await sendSubscriptionExpiryReminder({
        email: sub.email,
        contactName: sub.contactName,
        companyName: sub.companyName,
        serviceLabel: sub.serviceLabel,
        expiresAt: sub.expiresAt,
        daysLeft: 7,
        renewalToken: token,
      });
      // Atomic conditional update: only mark sent if not already flagged (idempotency)
      const result7d = await db.update(customerServiceSubscriptionsTable)
        .set({ renewalToken: token, renewalTokenExpiresAt: tokenExpiresAt, reminder7dSentAt: new Date() })
        .where(and(
          eq(customerServiceSubscriptionsTable.id, sub.id),
          isNull(customerServiceSubscriptionsTable.reminder7dSentAt),
        ));
      if ((result7d.rowCount ?? 0) === 0) {
        logger.warn({ subId: sub.id }, "7d reminder: row already marked, duplicate prevented");
      } else {
        logger.info({ subId: sub.id, email: sub.email }, "Subscription 7d reminder sent");
      }
    } catch (err) {
      logger.error({ err, subId: sub.id }, "Failed to send 7d reminder — will retry on next cron run");
    }
  }

  for (const sub of due1d) {
    if (!sub.expiresAt) continue;
    try {
      const token = generateRenewalToken();
      const tokenExpiresAt = new Date(Date.now() + 7 * 24 * 3600 * 1000);
      // Send email FIRST — flag is only written on success (write-after-send)
      await sendSubscriptionExpiryReminder({
        email: sub.email,
        contactName: sub.contactName,
        companyName: sub.companyName,
        serviceLabel: sub.serviceLabel,
        expiresAt: sub.expiresAt,
        daysLeft: 1,
        renewalToken: token,
      });
      // Atomic conditional update: only mark sent if not already flagged (idempotency)
      const result1d = await db.update(customerServiceSubscriptionsTable)
        .set({ renewalToken: token, renewalTokenExpiresAt: tokenExpiresAt, reminder1dSentAt: new Date() })
        .where(and(
          eq(customerServiceSubscriptionsTable.id, sub.id),
          isNull(customerServiceSubscriptionsTable.reminder1dSentAt),
        ));
      if ((result1d.rowCount ?? 0) === 0) {
        logger.warn({ subId: sub.id }, "1d reminder: row already marked, duplicate prevented");
      } else {
        logger.info({ subId: sub.id, email: sub.email }, "Subscription 1d reminder sent");
      }
    } catch (err) {
      logger.error({ err, subId: sub.id }, "Failed to send 1d reminder — will retry on next cron run");
    }
  }
}

export function startRenewalCron() {
  cron.schedule("0 9 * * *", async () => {
    try {
      await processSubscriptionRenewals();
    } catch (err) {
      logger.error({ err }, "Subscription renewal cron error");
    }
  }, { timezone: "Europe/Istanbul" });

  logger.info("Subscription renewal cron registered (09:00 Istanbul)");
}
